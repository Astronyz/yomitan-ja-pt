# Data licence — JMdict (Português)

Two copyright layers apply to the data in this repository and its releases:

1. **The Portuguese translation layer** — the machine-translated and
   community-corrected Portuguese glosses (`data/pt-gloss-cache.jsonl`,
   `data/overrides.jsonl`, `data/global-overrides.jsonl`, and the
   Portuguese strings in all built artifacts) —
   © Shiritai, offered under **Creative Commons Attribution-ShareAlike 4.0**
   (CC BY-SA 4.0).

2. **The underlying JMdict material** — Japanese headwords, readings,
   part-of-speech codes, sense structure, and English source glosses —
   © Electronic Dictionary Research and Development Group (EDRDG),
   distributed under the **EDRDG Licence** (see LICENSE-jmdict.html).

By contributing corrections you agree to license them under CC BY-SA 4.0.
The EDRDG licence requires attribution and is share-alike; redistributions
of the built artifacts must reproduce both attributions above.
